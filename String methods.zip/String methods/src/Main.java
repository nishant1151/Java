public class Main {
    public static void main(String args[]){
        Reversestring r1=new Reversestring();
        r1.reverseString();

        String str1="hello worlddd";
        System.out.println( str1.indexOf('d',str1.indexOf('l')+1));
        
    }
}
