//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String args[]){
        System.out.println("hello world");
    Simple_interest s1=new Simple_interest(7);
        System.out.println(s1.calculateRateOfInterest(10000,3));
    }
}